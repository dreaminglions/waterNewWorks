package com.ruoyi.rabbitmq.taskhandler;

public enum TaskType {
	ENERGY_ASK,
	ENERGY_PLC
}
