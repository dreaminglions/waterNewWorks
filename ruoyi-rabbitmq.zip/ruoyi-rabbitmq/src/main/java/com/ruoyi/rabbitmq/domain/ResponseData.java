package com.ruoyi.rabbitmq.domain;

public class ResponseData {
	private int key1;
	private int key2;
	private int key3;
	private int key4;
	private int key5;
	public int getKey1() {
		return key1;
	}
	public void setKey1(int key1) {
		this.key1 = key1;
	}
	public int getKey2() {
		return key2;
	}
	public void setKey2(int key2) {
		this.key2 = key2;
	}
	public int getKey3() {
		return key3;
	}
	public void setKey3(int key3) {
		this.key3 = key3;
	}
	public int getKey4() {
		return key4;
	}
	public void setKey4(int key4) {
		this.key4 = key4;
	}
	public int getKey5() {
		return key5;
	}
	public void setKey5(int key5) {
		this.key5 = key5;
	}
	
}
